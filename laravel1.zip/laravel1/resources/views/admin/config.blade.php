@extends('Layouts/admin')

@section('title', 'Configurações')

@section('content')
    
<h1>CONFIGURAÇÕES</h1>

@alert
Conteudo que eu quiser 
@endalert




<form method="POST">
@csrf

Nome:<br/>
<input type="text" name="nome" /><br/>

Idade:<br/>
<input type="text" name="idade" /><br/>

Cidade:<br/>
<input type="text" name="cidade" /><br/>


<input type="submit" value="Enviar" /><br/>
</form>

<a href="/config/info">Informações</a>

@endsection