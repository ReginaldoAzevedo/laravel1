<?php $__env->startSection('title', 'Edição de tarefas'); ?>

<?php $__env->startSection('content'); ?>
<h1>Edição</h1>

<?php if(session('warning')): ?>
<?php $__env->startComponent('components.alert'); ?>
<?php echo e(session('warning')); ?>

<?php echo $__env->renderComponent(); ?>

<?php endif; ?>


<form method="POST">
    <?php echo csrf_field(); ?>

    <label>
        Titulo:<br />
        <input type="text" name="titulo" value="<?php echo e($data->titulo); ?>"/>
    </label>

        <input type="submit" value="Salvar"/>


</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b7web\laravel1\resources\views/tarefas/edit.blade.php ENDPATH**/ ?>