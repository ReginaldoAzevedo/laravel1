
<div Style="border: 1px solid #FF0000;padding:20px;">
   
<?php echo e($slot); ?>

</div><?php /**PATH C:\xampp\htdocs\b7web\laravel1\resources\views/components/alert.blade.php ENDPATH**/ ?>