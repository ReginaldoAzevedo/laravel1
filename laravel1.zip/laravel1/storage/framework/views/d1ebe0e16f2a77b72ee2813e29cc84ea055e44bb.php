<?php $__env->startSection('title', 'Configurações'); ?>

<?php $__env->startSection('content'); ?>
    
<h1>CONFIGURAÇÕES</h1>

<?php $__env->startComponent('components.alert'); ?>
Conteudo que eu quiser 
<?php echo $__env->renderComponent(); ?>




<form method="POST">
<?php echo csrf_field(); ?>

Nome:<br/>
<input type="text" name="nome" /><br/>

Idade:<br/>
<input type="text" name="idade" /><br/>

Cidade:<br/>
<input type="text" name="cidade" /><br/>


<input type="submit" value="Enviar" /><br/>
</form>

<a href="/config/info">Informações</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b7web\laravel1\resources\views/admin/config.blade.php ENDPATH**/ ?>