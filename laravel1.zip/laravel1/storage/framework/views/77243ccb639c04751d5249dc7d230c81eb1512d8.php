<h1>CONFIGURAÇÕES</h1>
<a href ="config/info">Informações</a><?php /**PATH C:\xampp\htdocs\b7web\laravel1\resources\views/config.blade.php ENDPATH**/ ?>