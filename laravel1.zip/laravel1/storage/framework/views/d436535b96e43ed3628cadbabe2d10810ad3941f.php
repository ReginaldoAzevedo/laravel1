<?php $__env->startSection('title', 'Listagem de tarefas'); ?>

<?php $__env->startSection('content'); ?>
<h1>Listagem</h1>

<a href="<?php echo e(route('tarefas.add')); ?>">Adicionar nova tarefa</a>

<?php if(count($list)> 0): ?>
<ul>
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('tarefas.done', ['id'=>$item->id])); ?>">[<?php if($item->resolvido===1): ?> desmarcar   <?php else: ?> marcar <?php endif; ?>  ]</a>

            <?php echo e($item-> titulo); ?>


            <a href="<?php echo e(route('tarefas.edit', ['id'=>$item->id])); ?>">[Editar]</a>
            <a href="<?php echo e(route('tarefas.del', ['id'=>$item->id])); ?>" >[Excluir]</a>

        </li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php else: ?>

Não há itens a serem listados
    
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b7web\laravel1\resources\views/tarefas/list.blade.php ENDPATH**/ ?>