<?php $__env->startSection('title', 'Adição de tarefas'); ?>

<?php $__env->startSection('content'); ?>
<h1>Adição</h1>

<?php if(session('warning')): ?>
<?php $__env->startComponent('components.alert'); ?>
<?php echo e(session('warning')); ?>

<?php echo $__env->renderComponent(); ?>

<?php endif; ?>


<form method="POST">
    <?php echo csrf_field(); ?>

    <label>
        Titulo:<br />
        <input type="text" name="titulo"/>
    </label>

        <input type="submit" value="Adicionar"/>


</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b7web\laravel1\resources\views/tarefas/add.blade.php ENDPATH**/ ?>